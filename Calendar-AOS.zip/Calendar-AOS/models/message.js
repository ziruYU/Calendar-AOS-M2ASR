var mongoose = require('mongoose');

var messageSchema = mongoose.Schema({

    time: String,
    userSend:String,
    userReceive:String,
    eventId: String,
    content: String

});

module.exports = mongoose.model('Message', messageSchema);