$(document).ready(function() {
  /* Share an event from search result table */
  $('#eventform').on('click', '#btnShareEvent', editShare );
});

function editShare(e) {
  e.preventDefault();
  var inputData;
  /* Show form on dialog box to update an event */
  /* name attribute contains id value. From showEventsTable function in searchEvent.js */
  var shareId = $(this).attr('name');

  var date = new Date();
  var year = date.getFullYear();
  var month = date.getMonth()+1;
  var day = date.getDate();
  var hour = date.getHours();
  var minute = date.getMinutes();
  var second = date.getSeconds();
  var t=year+'/'+month+'/'+day+' '+hour+':'+minute+':'+second ;

  editFormHtmlUser();
  $('#dialog-share').dialog({
    height: 'auto',
    width: 'auto',
    modal: true,
    buttons: {
      OK: function() {
        /* Validate form input data when update button is clicked */
        inputData = processInputUser();
        /* If user has entered valid data. */
        if (!inputData.isInValid){

          var newShare = {
            'time': t,
            'userReceive': inputData.send,
            'eventId': shareId
          }
          shareEvent(newShare);

          $(this).dialog( 'close' );
        }
        /* If user has clicked update button without providing any input. Only show this
         * alert box if no alert box shown to user in processInputData().
         */
        else if (!inputData.alertValue && inputData.isInValid) {
          alert('Nothing to update. Press OK to continue.');
          $(this).dialog( 'close' );
        }
      },
      Close: function() {
        $( this ).dialog( 'close' );
      }
    }
  });
}

var editFormHtmlUser = function() {
  $('#dialog-share').html('' +
      '<form class="form" role="form">' +
      '<div class="form-group">' +
      '<label for="username">User Name:</label>' +
      '<input type="text" placeholder="user name" class="form-control" id="username" autofocus  />' +
      '</div>' +
      '</form>'
  );
}

var processInputUser = function() {
  var isInValid = true; /* Checks if user has entered valid data? */
  var sendData ;

  if ($('#dialog-share input#username').val()) {
    sendData = $('#dialog-share input#username').val();
    isInValid = false;
  }

  /* If user has not filled any field, isInValid will still be true, otherwise fasle. */
  return { isInValid: isInValid, send: sendData, alertValue: false };
};

function shareEvent(docs) {

  $.ajax({
    type: 'POST',
    data: docs,
    url: '/addmessage',
    dataType: 'JSON'
  }).done(function(res, status) {
    if (status) {
      window.location.replace('/home');
      alert('Event shared successully');
    } else {
      alert('Error: ' + res);
    }
  });
};



