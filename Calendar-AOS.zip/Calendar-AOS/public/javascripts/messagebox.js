$(document).ready(function() {
  /* Show form for adding an event. */
  $('#mesbox').on('click', addMessagehtml);
  /* Add event to database */
  $('#eventform').on('click', '#btnSendMessage', addMessage);
  /* Colse add event form */
  $('#eventform').on('click', '#btnCloseMessage', closeForm);

  $('#eventform').on('click', '#btnAddSharedEvent', addSharedEvent);
});

function addMessagehtml(e) {


  $.getJSON('/getmessages', function( data )
  {
    e.preventDefault();

    var tableContent = '';

    if (data && data.length) {

      $.each(data, function(){
        tableContent += '<tr>';
        tableContent += '<td>' + this.time + '</td>';
        tableContent += '<td>' + this.userSend + '</td>';
        tableContent += '<td>' + this.content + '</td>';
        tableContent += '<td>' + this.eventId + '</td>';
        tableContent += '<td><button id="btnAddSharedEvent" class="btn btn-success btn-sm" name=' + this.eventId  + '><span class="glyphicon glyphicon-check"></span> Add Shared Event</button></td>';
        tableContent += '</tr>';
      });


      $('#eventform').html(''+

          '<form class="form" role="form">' +
          '<legend><strong>Send Message</strong>:</legend>' +
          '<div class="col-sm-2">' +
          '<div class="form-group">' +
          '<label for="receive">User Receive:</label>' +
          '<input type="text" placeholder="user receive" maxlength="20" class="form-control" id="receive" />' +
          '</div> </div>' +
          '<div class="col-sm-10">' +
          '<div class="form-group">' +
          '<label for="context">Context:</label>' +
          '<input type="text" placeholder="context" maxlength="300" class="form-control" id="content" />' +
          '</div> </div> <br /> <br />' +
          '<div class="col-sm-5"></div>' +
          '<div class="btn-group">' +
          '<button id="btnSendMessage" class="btn btn-info"><span class="glyphicon glyphicon-send"></span> Send</button>' +
          '<button id="btnCloseMessage" class="btn btn-warning"><span class="glyphicon glyphicon-remove"></span> Close</button>' +
          '</div> <br />' +
          '</form>  <hr />'+

          '<h5><strong>Message List:</strong></h5>' +
          ' <div class="table-responsive">' +
          '   <table class="table table-striped table-bordered table-sm">' +
          '     <thead class="bg-success text-center">' +
          '       <tr><th>Send Time</th><th>User Send</th><th>Content</th><th>Event ID</th><th>Action</th></tr>' +
          '     </thead>' +
          '     <tbody>' + tableContent + '</tbody>' +
          '   </table>' +
          ' </div>' +
          '</div> <br />  <hr />'
      );
    }
  });
}

function addMessage(e) {
  e.preventDefault();
  var errorCnt = 0;

  var date = new Date();
  var year = date.getFullYear();
  var month = date.getMonth()+1;
  var day = date.getDate();
  var hour = date.getHours();
  var minute = date.getMinutes();
  var second = date.getSeconds();
  var t=year+'/'+month+'/'+day+' '+hour+':'+minute+':'+second ;



  /* Check if user has filled all fields? */
  $('#eventform input').each(function(index, val) {
    if($(this).val() === '') { errorCnt++; }
  });

  if(errorCnt === 0) {
      var dataMessage = {
        'time': t,
        'userReceive': $('#eventform input#receive').val(),
        'content': $('#eventform input#content').val()
      }
      $.ajax({
        type: 'POST',
        data: dataMessage,
        url: '/addmessage',
        dataType: 'JSON'
      }).done(function(res, status) {
        if (status) {
          window.location.replace('/home');
        } else {
          alert('Error: ' + res);
        }
      });
    } else {
    alert('Please fill in all fields.');
    return false;
  }
};

var addSharedEvent = function(e) {

    e.preventDefault();

    var sharedEvnetId = $(this).attr('name');

  $.getJSON('/getevent/' + sharedEvnetId, function( data ){

    if (data && data.length) {


        var newShare = {
          'startDate': this.startDate,
          'endDate': this.endDate,
          'startTime': this.startTime,
          'endTime': this.endTime,
          'description': this.description,
          'place': this.place

        }

        $.ajax({
          type: 'POST',
          data: newShare,
          url: '/addevent',
          dataType: 'JSON'
        }).done(function(res, status) {
          if (status) {
            window.location.replace('/home');
          } else {
            alert('Error: ' + res);
          }
        });
      }



  });
}